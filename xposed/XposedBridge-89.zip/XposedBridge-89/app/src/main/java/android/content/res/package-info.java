/**
 * Contains classes that are required for replacing resources.
 */
package android.content.res;
