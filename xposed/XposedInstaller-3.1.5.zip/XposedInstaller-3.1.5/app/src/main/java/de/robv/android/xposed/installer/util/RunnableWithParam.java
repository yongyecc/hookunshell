package de.robv.android.xposed.installer.util;

public interface RunnableWithParam<T> {
    public void run(T param);
}
